package co.com.proyectobase.screenplay.util;

public interface Builder<T> {
    T build();
}
