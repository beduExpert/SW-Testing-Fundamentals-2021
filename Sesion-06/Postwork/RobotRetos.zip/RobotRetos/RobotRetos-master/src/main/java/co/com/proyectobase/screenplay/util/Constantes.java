package co.com.proyectobase.screenplay.util;

public class Constantes {
    public static final String NAVEGADOR = "chrome";
    public static final Integer POSICION_REGISTRO = 0;
    public static final String DIA_REPORTADO = "diaReportado";
}
